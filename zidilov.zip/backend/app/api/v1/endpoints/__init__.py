# Empty file to make endpoints a Python package
